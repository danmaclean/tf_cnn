FLAGS <- flags(
  
  
  ## first convolution tuning parameters
  flag_string("regularizer1", "regularizer_l1", "regularizer in first convolution layer"),
  flag_numeric("reg1_rate", 0.01, "rate for regularizer1"),
  
  flag_integer("filter1",4, "Number of filters for first conv  set"),  
  flag_string("conv_activation1", "relu", "Activation Function for the first convolutions"),
  flag_integer("kernel1", 5 , "Size of kernel in first conv layer"),
  
  
  flag_boolean("do_max_pool1", TRUE, "do the max pool between 1st and subsequent conv layers"),
  flag_string("pool1_type", "max_pool", "use max or mean pooling"),
  flag_integer("pool1", 2, "Size of first pooling"),
  
  
  
  flag_boolean("do_drop1", TRUE, "use dropout after first conv layer"),
  flag_numeric("drop1", 0.01, "Dropout for the pooling"),
  
  flag_boolean("do_norm1", TRUE, "use batch norm after first conv layer"),
  
  
  ## optional conv tuning parameters
  flag_numeric("nconvlayers", 1, "Number of extra convolution layers"),
  flag_string("regularizer2", "regularizer_l1", "regularizer in extra convolution layers"),
  flag_numeric("reg2_rate", 0.01, "rate for regularizer2"),
  
  
  flag_integer("filter2",8, "Number of filters for second conv  set"),
  flag_string("conv_activation2", "relu", "Activation Function for the first convolutions"),
  flag_integer("kernel2", 5, "Size of kernel in extra conv layers"),
  
  
  flag_boolean("do_max_pool2", TRUE, "do the max pool between optional conv layers"),
  flag_string("pool2_type", "max_pool", "use max or mean pooling"),
  flag_integer("pool2", 2, "Size of extra conv layer poolings"),
  
  flag_boolean("do_drop2", TRUE, "use dropout after optional conv layers"),
  flag_numeric("drop2", 0.01, "Dropout for the pooling"),
  
  flag_boolean("conv_norm", TRUE, "use batch norm after each extra conv layer"),
  
  flag_boolean("do_post_conv_norm", TRUE, "use batch norm after last conv layer"),
  
  ## dense parameters
  
  
  flag_string("regularizer_dense1", "regularizer_l1", "regularizer in first dense layer"),
  flag_numeric("regdense1_rate", 0.001, "regularizer rate in first dense layer"),
  flag_numeric("ndense",1,"Number of extra dense layers"),
  
  
  flag_string("dense_activation","relu","Activation for the dense layers"),
  flag_numeric("hidden1",8, "Size of first dense layer"),
  flag_boolean("do_drop_dense1", TRUE, "Dropout for dense layers"),
  flag_boolean("do_drop_dense2", TRUE, "Dropout after dense layers"),
  
  flag_numeric("hidden2",8, "Size of subsequent dense layers"),
  
  ## training cycle parameters
  
  
  flag_integer("epochs", 40, "Number of epochs"),
  flag_integer("batch_size", 512, "Batch size"),
  
  flag_string("optimiser", "rmsprop", "Optimiser function"),
  flag_numeric("learn_rate", 0.001, "Learning Rate"),
  
)

model <- keras_model_sequential()

regularizer1 <- regularizer_l2(FLAGS$reg1_rate)
if (FLAGS$regularizer1 == "regularizer_l1"){
  regularizer1 <- regularizer_l1(FLAGS$reg1_rate)
} 

model %>%  
  layer_separable_conv_2d(filters = FLAGS$filter1, 
                          kernel_size = c(2,FLAGS$kernel1), 
                          depthwise_regularizer = regularizer1,
                          activation = FLAGS$conv_activation1, 
                          input_shape = c(2,232,1), 
                          padding = "same"
  )

if ( FLAGS$do_max_pool1 ) {
  if (FLAGS$pool1_type == "max_pool"){
    model %>% layer_max_pooling_2d(pool_size = c(FLAGS$pool1, FLAGS$pool1)) 
  } else if (FLAGS$pool1_type == "mean_pool") {
    model %>% layer_average_pooling_2d(pool_size = c(FLAGS$pool1, FLAGS$pool1)) 
  }
}
if (FLAGS$do_drop1){
  model %>%  layer_dropout(FLAGS$drop1) 
}
if (FLAGS$do_norm1){
  model %>% layer_batch_normalization()   
}
#  layer_separable_conv_2d(filters = 4, kernel_size = c(2,5), activation = "relu", input_shape = c(2,232,1), padding = "same") %>%
#  layer_max_pooling_2d(pool_size = c(2,2)) %>%

for (i in seq(1, FLAGS$nconvlayers)){
  
  
  regularizer2 <- regularizer_l2(FLAGS$reg2_rate)
  if (FLAGS$regularizer2 == "regularizer_l1"){
    regularizer2 <- regularizer_l1(FLAGS$reg2_rate)
  } 
  
  tryCatch(
    {
      model %>%  layer_separable_conv_2d(
        filter = FLAGS$filter2, 
        kernel_size = c(2,FLAGS$kernel2), 
        activation = FLAGS$conv_activation2,
        depthwise_regularizer = regularizer2,
        padding = "same"
      ) 
      
      if (FLAGS$conv_norm){
        model %>%  layer_batch_normalization()   
      } 
      
      if ( FLAGS$do_max_pool2 ) {
        if (FLAGS$pool2_type == "max_pool"){
          model %>% layer_max_pooling_2d(pool_size = c(FLAGS$pool2, FLAGS$pool2)) 
        } else if (FLAGS$pool2_type == "mean_pool") {
          model %>% layer_average_pooling_2d(pool_size = c(FLAGS$pool2, FLAGS$pool2)) 
        }
      }
      
      
      if (FLAGS$do_drop2){  
        model %>%  layer_dropout(FLAGS$drop2) 
      }
      
      if (FLAGS$do_post_conv_norm){
        model %>% layer_batch_normalization()   
      }
      
      
      
    }, 
    warning = function(w){ print("skipping incompatible layer") },
    error = function(e){ print("skipping incompatible layer") }
  )  

  model %>%  layer_flatten()
  #layer_separable_conv_2d(filters = 8, kernel_size = c(2,5), activation = "relu", padding = "same") %>%
  #layer_flatten() %>%
  
  regularizer_dense1 <- regularizer_l2(FLAGS$regdense1_rate)
  if (FLAGS$regularizer_dense1 == "regularizer_l1"){
    regularizer_dense1 <- regularizer_l1(FLAGS$regdense1_rate)
  } 
  
  model %>% layer_dense(
    FLAGS$hidden1, 
    activation = FLAGS$dense_activation1,
    kernel_regularizer =regularizer_dense1
  )
  
  if (FLAGS$do_drop_dense1){
    model %>% layer_dropout(FLAGS$drop2)
  }
  
  
  for (i in seq(1,FLAGS$ndense)){ 
    model %>% layer_dense(
      FLAGS$hidden2, 
      activation = FLAGS$dense_activation2,
      kernel_regularizer = regularizer_l2(0.01)
    )
    if (FLAGS$do_drop_dense2){
      model %>% layer_dropout(FLAGS$drop2)
    } 
  }
  
  #layer_dense(units = 8, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")


#
  opt <- optimizer_rmsprop(lr = FLAGS$learn_rate)
  if (FLAGS$optimiser == "sgd"){
    opt <- optimizer_sgd(lr = FLAGS$learn_rate)
  } else if (FLAGS$optimiser == "adam"){
    opt <- optimiser_adam(lr = FLAGS$learn_rate)
  }
  
model %>% compile(
  optimizer = "rmsprop",
  loss = "binary_crossentropy",
  metrics = c("accuracy")
)
#
callbacks_list <- list(
  callback_model_checkpoint(filepath = "bestepoch.h5", save_best_only = TRUE, save_weights_only = FALSE)
)

model %>% fit(
  x_train,
  y_train,
  epochs = FLAGS$epochs,
  batch_size = FLAGS$batch_size, 
  validation_data = list(x_val, y_val),
  callbacks = callbacks_list
)
